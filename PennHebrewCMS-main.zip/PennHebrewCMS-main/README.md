Sanity CMS for UPenn Hebrew exercises

In order to open the Sanity Studio

- npm install
- npm run dev