export default {
    name: 'course',
    title: 'Course',
    type: 'document',
    fields: [
        {name: 'name', title: 'Name', type: 'string'}
    ]
}