import quiz from './quiz'
import quizsection from './quizSection'
import question from './question'
import course from './course'
export const schemaTypes = [quiz, quizsection, question, course]
